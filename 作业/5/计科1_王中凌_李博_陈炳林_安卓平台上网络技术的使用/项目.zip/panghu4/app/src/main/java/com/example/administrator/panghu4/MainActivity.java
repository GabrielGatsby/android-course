package com.example.administrator.panghu4;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<New> newList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new Thread() {

            @Override

            public void run() {

                super.run();

                try {

                    String url = "https://xjh.haitou.cc/gz/uni-34";

                    Connection conn = Jsoup.connect(url);


                    // 修改http包中的header,伪装成浏览器进行抓取

                    conn.header("User-Agent", "Mozilla/5.0 (X11; Linux x86_64; rv:32.0) Gecko/    20100101 Firefox/32.0");

                    Document doc = conn.get();


                    // 获取tbody元素下的所有tr元素

                    Elements elements = doc.select("tbody tr");

                    for(Element element : elements) {


                        String company = element.getElementsByClass("text-success company pull-left").text();

                        String time = element.getElementsByClass("hold-ymd").text();

                        String address = element.getElementsByClass("text-ellipsis").text();

                        Elements pluswanzhi = element.select("a[href]");

                        String plus = pluswanzhi.attr("href");

                        New newc = new New(company, time, address, plus);

                        newList.add(newc);

                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                }


            }
                }.start();

        Button getnew = (Button)findViewById(R.id.getnew);
        getnew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
                LinearLayoutManager layoutManager = new LinearLayoutManager(MainActivity.this);
                recyclerView.setLayoutManager(layoutManager);
                NewAdapter adapter = new NewAdapter(newList);
                recyclerView.setAdapter(adapter);
            }
        });




    }
}





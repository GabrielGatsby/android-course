package com.example.administrator.panghu4;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Administrator on 2018/4/15.
 */

public class NewAdapter extends RecyclerView.Adapter<NewAdapter.ViewHolder> {

    private List<New> mNewList;

    static class ViewHolder extends RecyclerView.ViewHolder{
        View newView;
        TextView company;
        TextView address;
        TextView time;

        public ViewHolder(View view){
            super(view);
            newView = view;
            company = (TextView)view.findViewById(R.id.company);
            address = (TextView)view.findViewById(R.id.address);
            time = (TextView)view.findViewById(R.id.time);
        }
    }

    public NewAdapter(List<New> newList){
        mNewList = newList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.new_item, parent, false);
        final ViewHolder holder = new ViewHolder(view);
        holder.newView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = holder.getAdapterPosition();
                New newc = mNewList.get(position);
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://xjh.haitou.cc"+newc.plus));
                v.getContext().startActivity(intent);


            }
        });

        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        New newc = mNewList.get(position);
        holder.company.setText(newc.getCompany());
        holder.address.setText(newc.getAddress());
        holder.time.setText(newc.getTime());
    }

    @Override
    public int getItemCount() {
        return mNewList.size();
    }
}

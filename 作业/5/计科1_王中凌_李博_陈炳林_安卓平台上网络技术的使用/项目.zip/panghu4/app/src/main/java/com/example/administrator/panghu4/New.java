package com.example.administrator.panghu4;

/**
 * Created by Administrator on 2018/4/15.
 */

public class New {
    private String company;

    private String address;

    private String time;

    public String plus;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public New(String company, String address, String time, String plus) {
        this.address = address;
        this.company = company;
        this.time = time;
        this.plus = plus;
    }
}

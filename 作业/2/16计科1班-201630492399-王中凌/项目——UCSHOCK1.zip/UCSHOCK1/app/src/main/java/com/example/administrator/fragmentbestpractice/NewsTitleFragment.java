package com.example.administrator.fragmentbestpractice;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class NewsTitleFragment extends Fragment {

    private boolean isTwoPane;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.news_title_frag, container, false);
        RecyclerView newsTitleRecyclerView = (RecyclerView) view.findViewById(R.id.news_title_recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        newsTitleRecyclerView.setLayoutManager(layoutManager);
        NewsAdapter adapter = new NewsAdapter(getNews());
        newsTitleRecyclerView.setAdapter(adapter);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (getActivity().findViewById(R.id.news_content_layout) != null) {
            isTwoPane = true; // 可以找到news_content_layout布局时，为双页模式
        } else {
            isTwoPane = false; // 找不到news_content_layout布局时，为单页模式
        }
    }

    private List<News> getNews() {
        List<News> newsList = new ArrayList<>();
        for (int i = 1; i <= 50; i++) {
            int ran = (int) (Math.random() * 5 + 1);
            News news = new News();
            switch (ran){
                case 1:
                    news.setTitle("著名LOL玩家和DOTA玩家互斥对方不算男人 遭万人围观！");
                    news.setContent(new luosuodewenzhang().a);
                    news.setImageId(R.drawable.shock1);
                    break;
                case 2:
                    news.setTitle("震惊！99.99%的人都不知道的死法！男人看了会沉默，女人看了会流泪！");
                    news.setContent(new luosuodewenzhang().b);
                    news.setImageId(R.drawable.shock2);
                    break;
                case 3:
                    news.setTitle("老公决定了老婆的长相，看完后我惊呆了！");
                    news.setContent(new luosuodewenzhang().c);
                    news.setImageId(R.drawable.shock3);
                    break;
                case 4:
                    news.setTitle("中国人暴打美国人！没wifi都要看！");
                    news.setContent(new luosuodewenzhang().d);
                    news.setImageId(R.drawable.shock4);
                    break;
                case 5:
                    news.setTitle("半夜偷拍女生宿舍！不看不是男人！");
                    news.setContent(new luosuodewenzhang().e);
                    news.setImageId(R.drawable.shock5);
                    break;
            }
            newsList.add(news);
        }
        return newsList;
    }

    private String getRandomContent(int ran) {
        luosuodewenzhang gg = new luosuodewenzhang();
        switch (ran){
            case 1:
                return gg.a;
            case 2:
                return gg.b;
            case 3:
                return gg.c;
            case 4:
                return gg.d;
            case 5:
                return gg.e;
            default:
        }

        return gg.a;
    }

    class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.ViewHolder> {

        private List<News> mNewsList;

        class ViewHolder extends RecyclerView.ViewHolder {

            TextView newsTitleText;
            ImageView newsImage;

            public ViewHolder(View view) {
                super(view);
                newsTitleText = (TextView) view.findViewById(R.id.news_title);
                newsImage = (ImageView) view.findViewById(R.id.news_image);
            }

        }

        public NewsAdapter(List<News> newsList) {
            mNewsList = newsList;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_item, parent, false);
            final ViewHolder holder = new ViewHolder(view);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    News news = mNewsList.get(holder.getAdapterPosition());
                    if (isTwoPane) {
                        NewsContentFragment newsContentFragment = (NewsContentFragment)
                                getFragmentManager().findFragmentById(R.id.news_content_fragment);
                        newsContentFragment.refresh(news.getTitle(), news.getContent());
                    } else {
                        NewsContentActivity.actionStart(getActivity(), news.getTitle(), news.getContent());
                    }
                }
            });
            return holder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            News news = mNewsList.get(position);
            holder.newsTitleText.setText(news.getTitle());
            holder.newsImage.setImageResource(news.getImageId());
        }

        @Override
        public int getItemCount() {
            return mNewsList.size();
        }

    }

}
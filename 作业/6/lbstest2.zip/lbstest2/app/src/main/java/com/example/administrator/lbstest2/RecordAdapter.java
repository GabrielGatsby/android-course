package com.example.administrator.lbstest2;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Administrator on 2018/5/18.
 */

public class RecordAdapter extends RecyclerView.Adapter<RecordAdapter.ViewHolder>{
    private List<Record> mRecordList;

    static class ViewHolder extends RecyclerView.ViewHolder{
        View recordView;
        TextView itemc1;
        TextView itemc2;

        public ViewHolder(View view){
            super(view);
            recordView = view;
            itemc1 = (TextView)view.findViewById(R.id.itemc1);
            itemc2 = (TextView)view.findViewById(R.id.itemc2);
        }
    }

    public RecordAdapter(List<Record> RecordList){
        mRecordList = RecordList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item,parent, false);

        final ViewHolder holder = new ViewHolder(view);
        holder.recordView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                int position = holder.getAdapterPosition();
                Record record = mRecordList.get(position);
                Intent intent = new Intent(v.getContext(),SH.class);
                intent.putExtra("guojia",record.getGuojia());
                intent.putExtra("sheng",record.getSheng());
                intent.putExtra("shi",record.getShi());
                intent.putExtra("qu",record.getQu());
                intent.putExtra("jiedao",record.getJiedao());
                intent.putExtra("memory",record.getMemory());
                intent.putExtra("weidu",record.getWeidu());
                intent.putExtra("jingxian",record.getJingxian());
                v.getContext().startActivity(intent);
            }
        });

        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position){
        Record record = mRecordList.get(position);
        Log.d("ttt",record.getDate());
        holder.itemc1.setText(record.getShi());
        holder.itemc2.setText(record.getDate());


    }

    @Override
    public int getItemCount(){
        return mRecordList.size();
    }
}

package com.example.administrator.lbstest2;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import static java.util.Collections.reverse;

public class HI extends AppCompatActivity {

    private List<Record> recordList = new ArrayList<>();


    //数据库相关成员
    private MyDatabaseHelper dbHelper;

    //数据库相关数据成员
    private double weidut;
    private double jingxiant;
    private String guojiat;
    private String shengt;
    private String shit;
    private String qut;
    private String jiedaot;
    private int xuhaot;
    private String memoryt;
    private String datat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hi);

        //数据库相关函数
        dbHelper = new MyDatabaseHelper(this, "DataStore.db", null, 1);

        initList();
        RecyclerView recyclerView = (RecyclerView)findViewById(R.id.recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        RecordAdapter adapter = new RecordAdapter(recordList);
        recyclerView.setAdapter(adapter);
    }

    private void initList(){
        SQLiteDatabase db = dbHelper.getWritableDatabase();


        //查询表中数据
        Cursor cursor = db.query("History", null, null, null, null, null, null);

        if(cursor.moveToFirst()) {
            do {
                //遍历Cursor对象，取出数据并打印
                weidut = cursor.getDouble(cursor.getColumnIndex("weidu"));
                jingxiant = cursor.getDouble(cursor.getColumnIndex("jingxian"));
                guojiat = cursor.getString(cursor.getColumnIndex("guojia"));
                shengt = cursor.getString(cursor.getColumnIndex("sheng"));
                shit = cursor.getString(cursor.getColumnIndex("shi"));
                qut = cursor.getString(cursor.getColumnIndex("qu"));
                jiedaot = cursor.getString(cursor.getColumnIndex("jiedao"));
                xuhaot = cursor.getInt(cursor.getColumnIndex("xuhao"));
                memoryt = cursor.getString(cursor.getColumnIndex("memory"));
                datat = cursor.getString(cursor.getColumnIndex("date"));

                //存入类对象中
                Record record = new Record(datat,guojiat,jiedaot,memoryt,jingxiant,qut,shengt,shit,weidut,xuhaot);
                recordList.add(record);

            } while (cursor.moveToNext());

            reverse(recordList);
        }

        cursor.close();


    }
}

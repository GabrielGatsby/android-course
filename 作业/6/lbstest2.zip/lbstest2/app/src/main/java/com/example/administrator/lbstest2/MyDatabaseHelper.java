package com.example.administrator.lbstest2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

/**
 * Created by Administrator on 2018/5/17.
 */

public class MyDatabaseHelper extends SQLiteOpenHelper{

    public static final String CREATE_HISTORY = "create table History ("
            + "weidu real, "
            + "jingxian real, "
            + "guojia string, "
            + "sheng string, "
            + "shi string, "
            + "qu string, "
            + "jiedao string, "
            + "xuhao integer, "
            + "memory string, "
            + "date string)";
    private Context mContext;

    public MyDatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version){
        super(context, name, factory,version);
        mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL(CREATE_HISTORY);
        Toast.makeText(mContext, "Create succeeded", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("drop table if exists History");
        onCreate(db);
    }

}

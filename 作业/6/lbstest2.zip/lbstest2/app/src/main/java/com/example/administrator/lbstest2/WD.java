package com.example.administrator.lbstest2;

import android.Manifest;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.SDKInitializer;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class WD extends AppCompatActivity {

    public LocationClient mLocationClient;

    private TextView positionText;
    private EditText memory;

    private Button sure_memory;


    //数据库相关成员
    private MyDatabaseHelper dbHelper;

    //数据库相关数据成员
    private double weidut;
    private double jingxiant;
    private String guojiat;
    private String shengt;
    private String shit;
    private String qut;
    private String jiedaot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mLocationClient = new LocationClient(getApplicationContext());
        mLocationClient.registerLocationListener(new MyLocationListener());
        SDKInitializer.initialize(getApplicationContext());
        setContentView(R.layout.activity_wd);

        //数据库相关函数
        dbHelper = new MyDatabaseHelper(this, "DataStore.db", null, 1);


        positionText = (TextView) findViewById(R.id.position_text_view);
        List<String> permissionList = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(WD.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionList.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (ContextCompat.checkSelfPermission(WD.this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            permissionList.add(Manifest.permission.READ_PHONE_STATE);
        }
        if (ContextCompat.checkSelfPermission(WD.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            permissionList.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (!permissionList.isEmpty()) {
            String [] permissions = permissionList.toArray(new String[permissionList.size()]);
            ActivityCompat.requestPermissions(WD.this, permissions, 1);
        } else {
            requestLocation();
        }

        memory = (EditText)findViewById(R.id.memory);

        sure_memory =(Button)findViewById(R.id.sure_memory);
        sure_memory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(WD.this,"添加成功",Toast.LENGTH_SHORT).show();

                SharedPreferences pref = getSharedPreferences("data",MODE_PRIVATE);
                int times = pref.getInt("times", 0);//times是次数的意思
                if(times >= 50){
                    Toast.makeText(WD.this,"超过50，自动删除最早的一条",Toast.LENGTH_SHORT).show();
                    SQLiteDatabase db = dbHelper.getWritableDatabase();

                    //删除第一条记录
                    db.delete("History", "xuhao = ?", new String[]{"1"});

                    //重排剩下49条记录
                    for(int i = 2 ; i <= 50; i ++ ){
                        ContentValues values = new ContentValues();
                        values.put("xuhao", i-1);
                        db.update("History", values, "xuhao = ?", new String[]{String.valueOf(i)});
                    }

                    //插入最后的第50条记录
                    ContentValues values = new ContentValues();
                    values.put("weidu",weidut);
                    values.put("jingxian",jingxiant);
                    values.put("guojia",guojiat);
                    values.put("sheng",shengt);
                    values.put("shi",shit);
                    values.put("qu",qut);
                    values.put("jiedao",jiedaot);
                    values.put("xuhao", 50);

                    String memoryt = memory.getText().toString();
                    values.put("memory",memoryt);

                    SimpleDateFormat formatter    =   new    SimpleDateFormat    ("yyyy年MM月dd日    HH:mm:ss     ");
                    Date curDate    =   new    Date(System.currentTimeMillis());//获取当前时间
                    values.put("date", formatter.format(curDate) );

                    db.insert("History", null, values);
                }
                else{
                    //次数加1
                    SharedPreferences.Editor editor = getSharedPreferences("data",MODE_PRIVATE).edit();
                    editor.putInt("times", ++times);//times是次数的意思
                    editor.apply();

                   //添加记录入数据库
                    SQLiteDatabase db = dbHelper.getWritableDatabase();
                    ContentValues values = new ContentValues();

                    values.put("weidu",weidut);
                    values.put("jingxian",jingxiant);
                    values.put("guojia",guojiat);
                    values.put("sheng",shengt);
                    values.put("shi",shit);
                    values.put("qu",qut);
                    values.put("jiedao",jiedaot);
                    values.put("xuhao", times);

                    String memoryt = memory.getText().toString();
                    values.put("memory",memoryt);

                    SimpleDateFormat formatter    =   new    SimpleDateFormat    ("yyyy年MM月dd日    HH:mm:ss     ");
                    Date curDate    =   new    Date(System.currentTimeMillis());//获取当前时间
                    values.put("date", formatter.format(curDate) );


                    db.insert("History", null, values);



                }
            }
        });


    }


    private void requestLocation() {
        initLocation();
        mLocationClient.start();
    }

    private void initLocation(){
        LocationClientOption option = new LocationClientOption();
        option.setCoorType("bd09ll");
        option.setScanSpan(5000);
        option.setLocationMode(LocationClientOption.LocationMode.Device_Sensors);
        option.setIsNeedAddress(true);
        mLocationClient.setLocOption(option);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mLocationClient.stop();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0) {
                    for (int result : grantResults) {
                        if (result != PackageManager.PERMISSION_GRANTED) {
                            Toast.makeText(this, "必须同意所有权限才能使用本程序", Toast.LENGTH_SHORT).show();
                            finish();
                            return;
                        }
                    }
                    requestLocation();
                } else {
                    Toast.makeText(this, "发生未知错误", Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;
            default:
        }
    }

    public class MyLocationListener implements BDLocationListener {

        @Override
        public void onReceiveLocation(BDLocation location) {

           StringBuilder currentPosition = new StringBuilder();
           currentPosition.append("纬度：").append(location.getLatitude()).append("\n");
           currentPosition.append("经线：").append(location.getLongitude()).append("\n");
           currentPosition.append("国家：").append(location.getCountry()).append("\n");
           currentPosition.append("省：").append(location.getProvince()).append("\n");
           currentPosition.append("市：").append(location.getCity()).append("\n");
           currentPosition.append("区：").append(location.getDistrict()).append("\n");
           currentPosition.append("街道：").append(location.getStreet()).append("\n");
            weidut = location.getLatitude();
            jingxiant = location.getLongitude();
            guojiat = location.getCountry();
            shengt = location.getProvince();
            shit = location.getCity();
            qut = location.getDistrict();
            jiedaot = location.getStreet();

           currentPosition.append("定位方式：");
           if (location.getLocType() == BDLocation.TypeGpsLocation) {
               currentPosition.append("GPS");
           } else if (location.getLocType() == BDLocation.TypeNetWorkLocation) {
               currentPosition.append("网络");
           }
           positionText.setText(currentPosition);


        }

    }

}
package com.example.administrator.lbstest2;

/**
 * Created by Administrator on 2018/5/17.
 */

public class Record {

    private double weidu;
    private double jingxian;
    private String guojia;
    private String sheng;
    private String shi;
    private String qu;
    private String jiedao;
    private int xuhao;
    private String memory;
    private String date;

    public Record(String date, String guojia, String jiedao, String memory, double jingxian, String qu, String sheng, String shi, double weidu, int xuhao) {
        this.date = date;
        this.guojia = guojia;
        this.jiedao = jiedao;
        this.memory = memory;
        this.jingxian = jingxian;
        this.qu = qu;
        this.sheng = sheng;
        this.shi = shi;
        this.weidu = weidu;
        this.xuhao = xuhao;
    }

    public String getMemory() {
        return memory;
    }

    public void setMemory(String memory) {
        this.memory = memory;
    }

    public String getDate() {
        return date;
    }

    public String getGuojia() {
        return guojia;
    }

    public String getJiedao() {
        return jiedao;
    }

    public double getJingxian() {
        return jingxian;
    }

    public String getQu() {
        return qu;
    }

    public String getSheng() {
        return sheng;
    }

    public String getShi() {
        return shi;
    }

    public double getWeidu() {
        return weidu;
    }

    public int getXuhao() {
        return xuhao;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setGuojia(String guojia) {
        this.guojia = guojia;
    }

    public void setJiedao(String jiedao) {
        this.jiedao = jiedao;
    }

    public void setJingxian(double jingxian) {
        this.jingxian = jingxian;
    }

    public void setQu(String qu) {
        this.qu = qu;
    }

    public void setSheng(String sheng) {
        this.sheng = sheng;
    }

    public void setShi(String shi) {
        this.shi = shi;
    }

    public void setWeidu(double weidu) {
        this.weidu = weidu;
    }

    public void setXuhao(int xuhao) {
        this.xuhao = xuhao;
    }
}
